## Git hooks

El repositorio está configurado para ejecutar los tests antes de realizar
un commit, si se ejecuta este comando:

```bash
git config --local --add core.hookspath git-hooks
```
