package ar.uba.fi.ingsoft1.todo_template.user;

public interface UserCredentials {
    String username();
    String password();
}
