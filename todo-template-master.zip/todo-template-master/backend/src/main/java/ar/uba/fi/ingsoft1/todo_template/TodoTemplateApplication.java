package ar.uba.fi.ingsoft1.todo_template;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoTemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoTemplateApplication.class, args);
	}

}
